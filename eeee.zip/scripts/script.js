require([
    "esri/Map",
    "esri/views/SceneView",
    "dijit/form/Button"
], function(Map, SceneView, Button){
    const map1 = new Map({
        basemap: "streets-night-vector"
    });

    const view = new SceneView({
        map: map1,
        container: "mapDiv",
        zoom: 13,
        center: [53, 31]
    });

    const myButton = new Button({
        label: "Zmiana mapy bazowej",
        onclick: function() {
            map1.basemap = "topo"
        }
    }, "basemap_change");

});